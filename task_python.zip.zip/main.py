
from solutions import (
    q1_word_frequency,
    q2_character_frequency,
    q3_first_non_repeating,
    q4_are_anagrams,
    q5_first_repeating,
    q6_move_zeros,
    q7_second_highest,
    q8_remove_duplicates,
    q9_missing_number,
    q10_two_sum,
    q11_closest_to_zero,
    q12_common_elements,
    q13_rotate_right,
    q14_max_consecutive_sum,
    q15_all_pairs
)

# Q1
print("Q1:", q1_word_frequency(
    "python is easy and python is powerful"
))
print("Q1 Additional:", q1_word_frequency("cat dog cat"))

# Q2
print("Q2:", q2_character_frequency("banana"))
print("Q2 Additional:", q2_character_frequency("apple"))

# Q3
print("Q3:", q3_first_non_repeating("swiss"))
print("Q3 Additional:", q3_first_non_repeating("aabb"))

# Q4
print("Q4:", q4_are_anagrams("listen", "silent"))
print("Q4 Additional:", q4_are_anagrams("hello", "world"))

# Q5
print("Q5:", q5_first_repeating("programming"))
print("Q5 Additional:", q5_first_repeating("abcda"))

# Q6
print("Q6:", q6_move_zeros([0, 3, 0, 1, 2, 0, 4]))
print("Q6 Additional:", q6_move_zeros([1, 0, 2]))

# Q7
print("Q7:", q7_second_highest([10, 20, 40, 30, 40, 20]))
print("Q7 Additional:", q7_second_highest([5, 5, 3]))

# Q8
print("Q8:", q8_remove_duplicates([4, 2, 4, 5, 2, 7, 5]))
print("Q8 Additional:", q8_remove_duplicates([1, 1, 2, 3, 2]))

# Q9
print("Q9:", q9_missing_number([1, 2, 4, 5, 6], 6))
print("Q9 Additional:", q9_missing_number([1, 2, 3, 5], 5))

# Q10
print("Q10:", q10_two_sum([2, 7, 11, 15], 9))
print("Q10 Additional:", q10_two_sum([1, 4, 6], 20))

# Q11
print("Q11:", q11_closest_to_zero([-8, -3, 2, 5, -2]))
print("Q11 Additional:", q11_closest_to_zero([-4, 1, 3]))

# Q12
print("Q12:", q12_common_elements(
    [1, 2, 3, 4, 5], [3, 4, 5, 6, 7]
))
print("Q12 Additional:", q12_common_elements(
    [1, 2, 2, 3], [2, 3, 4]
))

# Q13
print("Q13:", q13_rotate_right([1, 2, 3, 4, 5], 2))
print("Q13 Additional:", q13_rotate_right([1, 2, 3], 1))

# Q14
print("Q14:", q14_max_consecutive_sum([4, 7, 2, 9, 5]))
print("Q14 Additional:", q14_max_consecutive_sum([1, 2, 3, 4]))

# Q15
print("Q15:", q15_all_pairs([2, 4, 3, 5, 7, 8, 1], 9))
print("Q15 Additional:", q15_all_pairs([1, 2, 3, 4], 5))

